from pathlib import Path

import pytesseract
#from pdf2image import convert_from_path
from PIL import Image

import re
import io
import time
import os



# get the current working directory
current_working_directory = Path.cwd()
print(current_working_directory)

extract_texts_file = "output\output_of_scanned_pdf_to_text.txt"
searched_file = "output\searched_to_text.txt"
searched_lines=[]

    # • Instant Booking Verification: Will use AI to verify guest identities and payment information in real-time to reduce the risk of fraudulent bookings.
