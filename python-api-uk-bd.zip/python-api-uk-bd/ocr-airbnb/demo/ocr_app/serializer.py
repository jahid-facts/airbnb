from rest_framework import serializers 
from ocr_app.models import Person, invoices
 
 
class PersonSerializer(serializers.ModelSerializer):
 
    class Meta:
        model = Person
        fields = ('nid',
                  'name',
                  'date_of_birth'
                  )


class InvoicesSerializer(serializers.ModelSerializer):
 
    class Meta:
        model = invoices
        fields = ('nid',
                  'name'
                  )
