from django.urls import re_path
from ocr_app import views
 
urlpatterns = [ 
    re_path(r'^api/$', views.users_list),
    re_path(r'^api/create', views.create_user),
    re_path(r'^api/instant_check', views.upload_file),
    
    # url(r'^api/tutorials/(?P<pk>[0-9]+)$', views.tutorial_detail),
    # url(r'^api/tutorials/published$', views.tutorial_list_published)
]
