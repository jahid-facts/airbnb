from django.shortcuts import render
from django.conf import settings
import os
  
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser 
from rest_framework.decorators import api_view
from rest_framework import status

from ocr_app.utils import ai_methods, regx_im, invoice_check
from ocr_app.models import Person

from ocr_app.serializer import PersonSerializer, InvoicesSerializer


# Create your views here.



@api_view(["POST"])
def upload_file(request):
    if request.method == 'POST':
        file = request.FILES['file']
        filename = 'uploaded_data_file' + "." + file.name.rsplit(".", 1)[1]
        file_path = os.path.join(settings.BASE_DIR, 'static', 'temp', filename)
        with open(file_path ,mode='wb+') as f:
            for chunk in file.chunks():
                f.write(chunk)
        file_url = settings.STATIC_URL + 'temp/' + filename
        #file.save("static/temp/" + filename)
        ai_methods.text_extracter(filename)
        regex_data = regx_im.text_to_info
        invoice_matched =  invoice_check.info_matching(regex_data)

        print(invoice_matched)
        if invoice_matched:
            response_data = {'success': 'okay'}
            return JsonResponse(response_data)
        
        return JsonResponse({'message':'File uploaded successfully and OCR is completed!'}, status=status.HTTP_201_CREATED) 
    return JsonResponse(status=status.HTTP_400_BAD_REQUEST)




@api_view(["GET"])
def results():
    try:
        with open('output/output_of_scanned_image_to_text.txt', 'r') as file:
            text = file.read()
            message = request.args.get('message')
            filename = request.args.get('filename')
            filename = "/temp/"+filename
        return render_template('result.html', message=message, text=text, filename=filename)
    except Exception as e:
        print(e)
        return '<h3> Error: could not load the text file, Invalid File Upload </h3>'




























@api_view(['GET'])
def users_list(request):
    if request.method == 'GET':
        users = Person.objects.all()
        
        person_name = request.GET.get('name', None)
        if person_name is not None:
            users = Person.filter(name__icontains=person_name)
        
        person_serializer = PersonSerializer(users, many=True)
        return JsonResponse(person_serializer.data, safe=False)
        # 'safe=False' for objects serialization


@api_view(['POST'])
def create_user(request):
    if request.method == 'POST':
        invoice_data = JSONParser().parse(request)
        invoices_serilizer = InvoicesSerializer(data=invoice_data)
        if invoices_serilizer.is_valid():
            invoices_serilizer.save()
            return JsonResponse(invoices_serilizer.data, status=status.HTTP_201_CREATED) 
        return JsonResponse(invoices_serilizer.errors, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST'])
# def create_user(request):
#     if request.method == 'POST':
#         paerson_data = JSONParser().parse(request)
#         paerson_serilizer = PersonSerializer(data=paerson_data)
#         if paerson_serilizer.is_valid():
#             paerson_serilizer.save()
#             return JsonResponse(paerson_serilizer.data, status=status.HTTP_201_CREATED) 
#         return JsonResponse(paerson_serilizer.errors, status=status.HTTP_400_BAD_REQUEST)









@api_view(['GET'])
def users_list(request):
    if request.method == 'POST':
        file = request.files['file'] # This part need to change
        filename = 'uploaded_data_file' + "." + file.filename.rsplit(".", 1)[1]
        file.save("static/temp/" + filename)
        #print(os.path.join(current_working_directory, filename))
        #file.save(os.path.join(current_working_directory, filename))
        text_extracter(filename)
        
        person_serializer = PersonSerializer(users, many=True)
        return JsonResponse(person_serializer.data, safe=False)
        # 'safe=False' for objects serialization


        # try:
        #     with open(file_path, 'wb+') as f:
        #         for chunk in file.chunks():
        #             f.write(chunk)
        #     # Set the file_upload variable to True if the file was uploaded successfully
        #     file_uploaded = True
        # except Exception as e:
        #     # Set the file_upload variable to False if there was an error
        #     file_uploaded = False
        #     print(e)
            
        # # Remove the form from the context dictionary
        # context = {'file_uploaded': file_uploaded}


# @api_view(['GET', 'POST'])
# def tutorial_list(request):
#     if request.method == 'GET':
#         persons = person.objects.all()
        
#         person_name = request.GET.get('name', None)
#         if person_name is not None:
#             tutorials = person.filter(name__icontains=person_name)
        
#         person_serializer = PersonSerializer(person, many=True)
#         return JsonResponse(person_serializer.data, safe=False)
#         # 'safe=False' for objects serialization
#     elif request.method == 'POST':
#         tutorial_data = JSONParser().parse(request)
#         tutorial_serializer = TutorialSerializer(data=tutorial_data)
#         if tutorial_serializer.is_valid():
#             tutorial_serializer.save()
#             return JsonResponse(tutorial_serializer.data, status=status.HTTP_201_CREATED) 
#         return JsonResponse(tutorial_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['GET', 'PUT', 'DELETE'])
# def person_detail(request, pk):
#     # ... tutorial = Tutorial.objects.get(pk=pk)
 
#     if request.method == 'GET': 
#         tutorial_serializer = TutorialSerializer(tutorial) 
#         return JsonResponse(tutorial_serializer.data) 




# Here is a complete list of all the lookup operators available in Django:

# 1. `exact`
# 2. `iexact`
# 3. `contains`
# 4. `icontains`
# 5. `in`
# 6. `gt`
# 7. `gte`
# 8. `lt`
# 9. `lte`
# 10. `startswith`
# 11. `istartswith`
# 12. `endswith`
# 13. `iendswith`
# 14. `range`
# 15. `date`
# 16. `year`
# 17. `month`
# 18. `day`
# 19. `week_day`
# 20. `hour`
# 21. `minute`
# 22. `second`
# 23. `isnull`
# 24. `regex`
# 25. `iregex`
# 26. `search`
# 27. `overlap`
# 28. `contains`
# 29. `contained_by`
# 30. `has_key`
# 31. `has_any_keys`
# 32. `has_keys`
# 33. `json_contains`
# 34. `json_contains_any`
# 35. `json_extract`
# 36. `json_annotate`
# 37. `collate`

# Each of these lookups can be used to filter data from a Django model in a different way. Some of them, like `exact` and `icontains`, are used very frequently, while others, such as `json_annotate`, are much less commonly used but are still available for more complex queries.