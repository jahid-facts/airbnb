const sidebarContent = [
  {
    name: "Host Dashboard",
    path: "/hosting",
    icon: "uil:chart",
  },
  {
    name: "Property List",
    path: "/property/list",
    icon: "clarity:building-line",
  },
  {
    name: "Reservation check-in",
    path: "/e-check",
    icon: "clarity:building-line",
  },
];

export default sidebarContent;
 