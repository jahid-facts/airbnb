import React from "react";
import { OtpComponent } from "../../components/OTP";

const OtpScreen = () => {
  return (
    <div>
      <OtpComponent />
    </div>
  );
};

export default OtpScreen;
