import { Stack } from '@mui/material';
import React from 'react';

export default function Footer() {
  return (
    <Stack>
      footer
    </Stack>
  );
}
