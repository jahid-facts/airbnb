export default {
  maptiler: {
    url: "https://api.maptiler.com/maps/basic-v2/{z}/{x}/{y}.png?key=MFBe4QAsT7i5ePcBNUVQ",
    attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  },
};
