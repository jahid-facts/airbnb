import { Box } from "@mui/material";
import React from "react";

export const Feed = () => {
  return (
    <>
      <Box flex={6} p={{ xs: 0, md: 2 }}>
       <h4>feed</h4>
      </Box>
    </>
  );
};
